#!/usr/bin/env python3
"""
TidyUUUUp - 智能工作台
Liquid Glass 设计的 Windows 任务栏替代品

支持：
  - 文件智能整理、快速索引搜索
  - 智能桌面监控，新文件1秒内自动分类
  - 虚拟分类文件夹（工作/娱乐/学习/图片/下载...）
  - 悬浮球模式（不使用时最小化为小圆球）
  - 全部功能永久免费使用
"""

import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt5.QtCore import Qt, QTimer, QPoint
from PyQt5.QtWidgets import QApplication, QSystemTrayIcon, QMenu, QAction, QMessageBox
from PyQt5.QtGui import QIcon, QPixmap, QPainter, QColor, QFont

from ui.styles import apply_liquid_glass
from ui.dock_bar import DockBar
from ui.main_window import MainWindow
from ui.floating_ball import FloatingBall
from ui.zone_panel import ZonePanel, ZoneFolderButton

from core.smart_engine import SmartRuleEngine
from core.desktop_watcher import DesktopWatcher
from core.updater import UpdateChecker, CURRENT_VERSION


def create_app_icon():
    pixmap = QPixmap(64, 64)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)

    from PyQt5.QtGui import QLinearGradient
    gradient = QLinearGradient(0, 0, 64, 64)
    gradient.setColorAt(0, QColor(100, 150, 255))
    gradient.setColorAt(1, QColor(180, 100, 255))
    painter.setBrush(gradient)
    painter.setPen(Qt.NoPen)
    painter.drawRoundedRect(4, 4, 56, 56, 16, 16)

    painter.setPen(QColor(255, 255, 255, 230))
    font = QFont()
    font.setBold(True)
    font.setPointSize(28)
    painter.setFont(font)
    painter.drawText(pixmap.rect(), Qt.AlignCenter, "◇")

    painter.end()
    return QIcon(pixmap)


class TidyUUUUpApp:
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.app.setQuitOnLastWindowClosed(False)
        self.app.setApplicationName("TidyUUUUp")

        apply_liquid_glass(self.app)

        self.icon = create_app_icon()
        self.app.setWindowIcon(self.icon)

        # 核心模块
        self.smart_engine = SmartRuleEngine()

        # 窗口
        self.main_window = MainWindow()
        screen = self.app.primaryScreen().geometry()
        self.dock = DockBar(screen)

        # 桌面监控
        self.desktop_watcher = DesktopWatcher(self.smart_engine)
        self.desktop_watcher.file_detected.connect(self._on_file_detected)
        self.desktop_watcher.organize_completed.connect(self._on_organize_completed)

        # 悬浮球
        self.floating_ball = FloatingBall()
        self.floating_ball.clicked.connect(self._toggle_ball_mode)
        self.floating_ball.double_clicked.connect(self.main_window.show)
        self.floating_ball.right_clicked.connect(self._show_ball_menu)
        self._ball_mode = 'dock'

        # 智能分类面板
        self.zone_panel = ZonePanel(self.smart_engine, self.main_window.file_index)
        self._zone_buttons = []

        # 信号连接
        self.dock.search_triggered.connect(self._show_main_and_focus_search)
        self.dock.files_triggered.connect(self.main_window.show)
        self.dock.organizer_triggered.connect(self._show_organizer_tab)
        self.main_window.show_dock.connect(self.dock._show_dock)

        # 系统托盘
        self._setup_tray()

        # 默认应用
        self._load_default_apps()

        # 智能分类文件夹按钮
        self._load_zone_buttons()

        # 启动桌面监控
        QTimer.singleShot(2000, self._start_desktop_watcher)

        # 启动后 3 秒检查更新（不影响启动速度）
        QTimer.singleShot(3000, self._check_updates)

    def _setup_tray(self):
        self.tray = QSystemTrayIcon(self.icon)
        self.tray.setToolTip("TidyUUUUp")

        menu = QMenu()
        menu.setStyleSheet("""
            QMenu {
                background: rgba(35, 35, 50, 0.95);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 10px;
                padding: 6px;
                color: white;
            }
            QMenu::item {
                padding: 8px 20px;
                border-radius: 6px;
                font-size: 13px;
            }
            QMenu::item:hover {
                background: rgba(100, 150, 255, 0.35);
            }
            QMenu::separator {
                height: 1px;
                background: rgba(255,255,255,0.1);
                margin: 4px 8px;
            }
        """)

        show_main = QAction("📋 打开主界面", self.app)
        show_main.triggered.connect(self.main_window.show)
        menu.addAction(show_main)

        show_dock = QAction("🪟 显示Dock栏", self.app)
        show_dock.triggered.connect(self._show_dock_and_ball)
        menu.addAction(show_dock)

        toggle_ball = QAction("🟢 悬浮球模式", self.app)
        toggle_ball.triggered.connect(self._toggle_ball_mode)
        menu.addAction(toggle_ball)

        menu.addSeparator()

        organize_action = QAction("🧹 整理桌面", self.app)
        organize_action.triggered.connect(self._organize_desktop)
        menu.addAction(organize_action)

        rescan = QAction("🔄 重新扫描文件", self.app)
        rescan.triggered.connect(self._rescan_files)
        menu.addAction(rescan)

        menu.addSeparator()

        about_action = QAction(f"ℹ️  关于 (v{CURRENT_VERSION})", self.app)
        about_action.triggered.connect(self._show_about)
        menu.addAction(about_action)

        check_update_action = QAction("🔄  检查更新", self.app)
        check_update_action.triggered.connect(lambda: self._check_updates(force=True))
        menu.addAction(check_update_action)

        menu.addSeparator()

        quit_action = QAction("退出", self.app)
        quit_action.triggered.connect(self._quit)
        menu.addAction(quit_action)

        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._on_tray_activated)
        self.tray.show()

    def _on_tray_activated(self, reason):
        if reason == QSystemTrayIcon.Trigger:
            if self._ball_mode == 'ball':
                self._toggle_ball_mode()
            else:
                if self.main_window.isVisible():
                    self.main_window.hide()
                else:
                    self.main_window.show()

    def _show_main_and_focus_search(self):
        self.main_window.show()
        self.main_window.raise_()
        self.main_window.activateWindow()
        QTimer.singleShot(100, lambda: self.main_window.search_box.setFocus())

    def _show_organizer_tab(self):
        self.main_window.show()
        self.main_window.raise_()
        self.main_window.activateWindow()
        self.main_window.tabs.setCurrentIndex(1)

    def _rescan_files(self):
        self.main_window._initial_scan()
        self._update_zone_file_counts()

    def _show_toast(self, msg):
        self.main_window.toast.show_toast(msg, 3000)

    def _load_default_apps(self):
        default_apps = [
            ("文件资源管理器", "explorer.exe"),
            ("Chrome", r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
            ("Edge", r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
            ("VS Code", r"C:\Users\%USERNAME%\AppData\Local\Programs\Microsoft VS Code\Code.exe"),
            ("设置", "ms-settings:"),
        ]

        config_path = os.path.join(os.path.expanduser('~'), '.nexus_dock', 'dock_config.json')
        apps_to_load = default_apps

        if os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    apps_to_load = config.get('apps', default_apps)
            except Exception:
                pass

        for name, path in apps_to_load:
            expanded_path = os.path.expandvars(path)
            self.dock.add_app(name, expanded_path)

    # ============ 智能分类文件夹 ============

    def _load_zone_buttons(self):
        zones = self.smart_engine.get_all_zones()

        for zone_name, zone_config in zones.items():
            btn = ZoneFolderButton(zone_name, zone_config)
            btn.zone_clicked.connect(self._on_zone_clicked)
            self._zone_buttons.append(btn)
            self.dock.apps_layout.addWidget(btn)
            self.dock._all_items.append(btn)

        self.dock._magnify.items = self.dock._all_items
        QTimer.singleShot(3000, self._update_zone_file_counts)

    def _update_zone_file_counts(self):
        if not self.main_window.file_index:
            return

        for btn in self._zone_buttons:
            count = 0
            for filepath, info in self.main_window.file_index.index.items():
                zone, _ = self.smart_engine.classify(filepath)
                if zone == btn.zone_name:
                    count += 1
            btn.set_file_count(count)

    def _on_zone_clicked(self, zone_name):
        btn = self.sender()
        if btn:
            global_pos = btn.mapToGlobal(btn.rect().center())
            self.zone_panel.show_zone(zone_name, global_pos)

    # ============ 桌面监控 ============

    def _start_desktop_watcher(self):
        self.desktop_watcher.start()
        self.desktop_watcher.ensure_zone_folders()
        self._show_toast("👀 桌面实时监控已启动，新文件将自动分类")

    def _on_file_detected(self, filepath, zone):
        filename = os.path.basename(filepath)
        self._show_toast(f"📁 已自动分类: {filename[:20]} → {zone}")
        self._update_zone_file_counts()

    def _on_organize_completed(self, results):
        total = results.get('total', 0)
        organized = results.get('organized', {})
        msg = f"✅ 桌面整理完成！共处理 {total} 个文件\n"
        for zone, files in organized.items():
            msg += f"  {zone}: {len(files)} 个\n"
        QMessageBox.information(self.main_window, "整理完成", msg)
        self._update_zone_file_counts()

    def _organize_desktop(self):
        reply = QMessageBox.question(
            self.main_window, "整理桌面",
            "是否将桌面上所有文件自动分类到对应的文件夹？\n\n"
            "文件将被移动到 桌面/智能分类/ 目录下",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self._show_toast("🔄 正在整理桌面...")
            QTimer.singleShot(100, lambda: self.desktop_watcher.organize_all())

    # ============ 悬浮球模式 ============

    def _toggle_ball_mode(self):
        if self._ball_mode == 'dock':
            self.dock.hide()
            self.floating_ball.show()
            self._ball_mode = 'ball'
            self._show_toast("🟢 已切换到悬浮球模式，双击展开")
        else:
            self.floating_ball.hide()
            self.dock.show()
            self._ball_mode = 'dock'
            self._show_toast("🪟 已切换到Dock栏模式")

    def _show_dock_and_ball(self):
        if self._ball_mode == 'ball':
            self._toggle_ball_mode()
        else:
            self.dock._show_dock()

    def _show_ball_menu(self, pos):
        menu = QMenu()
        menu.setStyleSheet("""
            QMenu {
                background: rgba(35, 35, 50, 0.95);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 10px;
                padding: 6px;
                color: white;
            }
            QMenu::item {
                padding: 8px 20px;
                border-radius: 6px;
                font-size: 13px;
            }
            QMenu::item:hover {
                background: rgba(100, 150, 255, 0.35);
            }
        """)

        show_main = QAction("📋 打开主界面", self.app)
        show_main.triggered.connect(self.main_window.show)
        menu.addAction(show_main)

        toggle = QAction("🪟 切换到Dock栏", self.app)
        toggle.triggered.connect(self._toggle_ball_mode)
        menu.addAction(toggle)

        menu.addSeparator()

        organize = QAction("🧹 整理桌面", self.app)
        organize.triggered.connect(self._organize_desktop)
        menu.addAction(organize)

        menu.exec_(pos)

    # ============ 自动更新 ============

    def _check_updates(self, force=False):
        """检查更新"""
        self.update_checker = UpdateChecker()
        self.update_checker.check_finished.connect(lambda has_update, info: self._on_update_checked(has_update, info, force))
        self.update_checker.error_occurred.connect(lambda err: self._on_update_error(err, force))
        self.update_checker.start()

    def _on_update_checked(self, has_update, info, force=False):
        if has_update:
            if force:
                # 手动检查才弹窗
                from ui.update_dialog import UpdateDialog
                self.update_dialog = UpdateDialog(info)
                self.update_dialog.show_at_center()
            else:
                # 自动检查只显示 toast 提示，不弹窗打扰
                self._show_toast(f"🔄 发现新版本 v{info.get('latest_version','')}，右键托盘 → 检查更新 可更新")
        elif force:
            # 手动检查但没有更新
            self._show_toast(f"✅ 当前已是最新版本 (v{CURRENT_VERSION})")

    def _on_update_error(self, error, force=False):
        if force:
            self._show_toast(f"❌ 检查更新失败: {error}")

    def _show_about(self):
        from PyQt5.QtWidgets import QDialog, QLabel, QVBoxLayout, QPushButton
        dialog = QDialog()
        dialog.setWindowTitle("关于 TidyUUUUp")
        dialog.setFixedSize(400, 240)
        dialog.setStyleSheet("background: rgba(30, 30, 50, 0.98); color: white; border-radius: 16px;")

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(30, 30, 30, 20)

        title = QLabel("✨  TidyUUUUp")
        title.setStyleSheet("font-size: 22px; font-weight: 700;")
        title.setAlignment(Qt.AlignCenter)

        version = QLabel(f"版本 v{CURRENT_VERSION}")
        version.setStyleSheet("color: rgba(255,255,255,0.5); font-size: 13px;")
        version.setAlignment(Qt.AlignCenter)

        desc = QLabel("Liquid Glass 设计的智能工作台\n文件自动整理 · 桌面实时监控")
        desc.setStyleSheet("color: rgba(255,255,255,0.7); font-size: 13px;")
        desc.setAlignment(Qt.AlignCenter)

        close_btn = QPushButton("关闭")
        close_btn.setFixedHeight(38)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.1);
                color: white;
                border: none;
                border-radius: 10px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover { background: rgba(255, 255, 255, 0.18); }
        """)
        close_btn.clicked.connect(dialog.accept)

        layout.addWidget(title)
        layout.addWidget(version)
        layout.addSpacing(10)
        layout.addWidget(desc)
        layout.addStretch()
        layout.addWidget(close_btn)

        dialog.exec_()

    def _quit(self):
        self.dock.close()
        self.main_window.close()
        self.floating_ball.close()
        self.zone_panel.close()
        self.tray.hide()
        try:
            self.desktop_watcher.stop()
        except Exception:
            pass
        QApplication.quit()

    def run(self):
        self.dock.show()

        QTimer.singleShot(
            1000,
            lambda: self.main_window.toast.show_toast("✨ TidyUUUUp 已启动！", 5000)
        )

        sys.exit(self.app.exec_())


def main():
    app = TidyUUUUpApp()
    app.run()


if __name__ == "__main__":
    main()
